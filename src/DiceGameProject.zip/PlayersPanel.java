import javax.swing.*;
import java.awt.*;

public class PlayersPanel extends JPanel{
    private JPanel player1Panel;
    private JPanel player2Panel;
    private JLabel player1;
    private JLabel Image1;
    private JLabel p1Wins;
    private int counter1=0;
    private JLabel player2;
    private JLabel Image2;
    private JLabel p2Wins;
    private int counter2=0;
    private Die die;

    public PlayersPanel(Die die){
        setLayout(new GridLayout(1,2));
        this.die = die;

        player1Panel = new JPanel();
        player2Panel = new JPanel();

        player1 = new JLabel("Player 1");
        player2 = new JLabel("Player 2");
        Image1 = new JLabel();
        Image2 = new JLabel();
        p1Wins = new JLabel(counter1+ "");
        p2Wins = new JLabel(counter2+ "");


        player1Panel.setLayout(new GridLayout(3,1));
        player1Panel.add(player1,BorderLayout.NORTH);
        player1.setHorizontalAlignment(JLabel.CENTER);
        player1Panel.add(Image1,BorderLayout.SOUTH);
        Image1.setHorizontalAlignment(JLabel.CENTER);
        player1Panel.add(p1Wins,BorderLayout.SOUTH);
        p1Wins.setHorizontalAlignment(JLabel.CENTER);
        p1Wins.setFont(new Font("Arial",Font.PLAIN,26));

        player2Panel.setLayout(new GridLayout(3,1));
        player2Panel.add(player2,BorderLayout.NORTH);
        player2.setHorizontalAlignment(JLabel.CENTER);
        player2Panel.add(Image2,BorderLayout.SOUTH);
        Image2.setHorizontalAlignment(JLabel.CENTER);
        player2Panel.add(p2Wins,BorderLayout.SOUTH);
        p2Wins.setHorizontalAlignment(JLabel.CENTER);
        p2Wins.setFont(new Font("Arial",Font.PLAIN,26));

        add(player1Panel);
        add(player2Panel);

        Image1.setIcon(die.rolled(0));
        Image2.setIcon(die.rolled(0));
    }

    /**
     * The pRoll method uses the 2 values to display the image of the dice
     * corresponding to each value for each player.
     * @param value1 Die value of player 1
     * @param value2 Die value of player 2
     */
    public void pRoll(int value1, int value2){
            Image1.setIcon(die.rolled(value1));
            Image2.setIcon(die.rolled(value2));
            if (value1>value2){
                counter1++;
                p1Wins.setText(player1.getText()+" Wins! " +counter1);
                p2Wins.setText(counter2+"");
            }
            else if (value1<value2){
                counter2++;
                p2Wins.setText(player2.getText()+" Wins! " +counter2);
                p1Wins.setText(counter1+"");
            }
            else{
                p2Wins.setText("It's a draw! " +counter2);
                p1Wins.setText("It's a draw! " +counter1);
                //JOptionPane.showMessageDialog(null,"It's a tie for this round!");
            }
    }

    public String getPlayer1(){
        return player1.getText();
    }

    public String getPlayer2(){
        return player2.getText();
    }

    public void setPlayer1(String name){
        player1.setText(name);
    }

    public void setPlayer2(String name){
        player2.setText(name);
    }

    public void resetScores(){
        counter1=0;
        counter2=0;
        p1Wins.setText(counter1+"");
        p2Wins.setText(counter2+"");
    }
}
