import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Die {
    private ImageIcon [] DieSide;
    private BufferedImage Die1,Die2,Die3,Die4,Die5,Die6;

    public Die(){
        loadDefault();
    }

    public ImageIcon rolled(int randomValue){
        return DieSide[randomValue];
    }

    public void loadDefault(){
        Die1=null;Die2=null;Die3=null;Die4=null;Die5=null;Die6=null;
        try {
            Die1 = ImageIO.read(new File("src/Die1.png"));
            Die2 = ImageIO.read(new File("src/Die2.png"));
            Die3 = ImageIO.read(new File("src/Die3.png"));
            Die4 = ImageIO.read(new File("src/Die4.png"));
            Die5 = ImageIO.read(new File("src/Die5.png"));
            Die6 = ImageIO.read(new File("src/Die6.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        DieSide = new ImageIcon[]{new ImageIcon(Die1), new ImageIcon(Die2),new ImageIcon(Die3),
                new ImageIcon(Die4), new ImageIcon(Die5), new ImageIcon(Die6)};
    }

    public void loadRed(){
        Die1=null;Die2=null;Die3=null;Die4=null;Die5=null;Die6=null;
        try {
            Die1 = ImageIO.read(new File("src/Die1r.png"));
            Die2 = ImageIO.read(new File("src/Die2r.png"));
            Die3 = ImageIO.read(new File("src/Die3r.png"));
            Die4 = ImageIO.read(new File("src/Die4r.png"));
            Die5 = ImageIO.read(new File("src/Die5r.png"));
            Die6 = ImageIO.read(new File("src/Die6r.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        DieSide = new ImageIcon[]{new ImageIcon(Die1), new ImageIcon(Die2),new ImageIcon(Die3),
                new ImageIcon(Die4), new ImageIcon(Die5), new ImageIcon(Die6)};
    }
}
