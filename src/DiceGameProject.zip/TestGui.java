import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class TestGui extends JFrame{
    private JLabel imgPlayer1;
    private JLabel imgPlayer2;
    private PlayersPanel players;
    private Menu menuOptions;
    private JButton btn;
    private Die die;
    private Random randomRoll;

    public TestGui(){
        randomRoll = new Random();
        die = new Die();
        Container cp = getContentPane();
//        cp.setLayout(new FlowLayout());

//        cp.add(new JLabel("Une image :"));
//        imgPlayer1 = new JLabel(die.rolled(1));
//        cp.add(imgPlayer1);

        players = new PlayersPanel(die);
        menuOptions = new Menu(players,die);
        cp.add(menuOptions,BorderLayout.NORTH);
        cp.add(players);
//        players.pRoll(0,0);

        btn = new JButton("Test?");
        btn.addActionListener(new TestButtonListener());
        cp.add(btn,BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("2 Player Dice Game");
//        setSize(600,350);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private class TestButtonListener implements ActionListener{
        private int playerRoll1;
        private int playerRoll2;
        @Override
        public void actionPerformed(ActionEvent e) {
            playerRoll1 = randomRoll.nextInt(6);
            playerRoll2 = randomRoll.nextInt(6);
            System.out.println(playerRoll1 + " - " + playerRoll2);
            players.pRoll(playerRoll1,playerRoll2);
//            players.p2Roll(playerRoll2);
//            imgPlayer1.setIcon(die.rolled(playerRoll1));

        }
    }

    public static void main(String [] args){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TestGui(); // Let the constructor do the job
            }
        });

    }
}

