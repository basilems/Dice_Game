import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends JMenuBar {
    private JMenu help;
    private JMenu game;
    private JMenu themes;
    private JMenuItem def,red;
    private JMenuItem reset, changeName1, changeName2, helpBtn;
    private PlayersPanel gameInfo;
    private Die die;

    public Menu(PlayersPanel panel,Die die){
        game = new JMenu("Game");
        help = new JMenu("Help");
        themes = new JMenu("Themes");
        gameInfo = panel;
        this.die = die;

        reset = new JMenuItem("Reset Game");
        reset.addActionListener(new ResetListener());
        changeName1 = new JMenuItem("Change Player1 name");
        changeName1.addActionListener(new Player1NameListener());
        changeName2 = new JMenuItem("Change Player2 name");
        changeName2.addActionListener(new Player2NameListener());

        def = new JMenuItem("Default theme");
        def.addActionListener(new DefaultThemeListener());
        red = new JMenuItem("Red theme");
        red.addActionListener(new RedThemeListener());
        themes.add(def);
        themes.add(red);

        helpBtn = new JMenuItem("Show help?");
        helpBtn.addActionListener(new HelpListener());
        game.add(reset);
        game.add(changeName1);
        game.add(changeName2);
        help.add(helpBtn);
        add(game);
        add(themes);
        add(help);
    }

    private class HelpListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null,"Welcome to our dice game!\n" +
                    "The aim of the game is simple : get a better score\n" +
                    "than the other player. If you both roll the same \n" +
                    "number, it's a draw and no one wins the round.\n" +
                    "Enjoy the game!");
        }
    }

    private class ResetListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            gameInfo.resetScores();
        }
    }

    private class Player1NameListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String p1Name = JOptionPane.showInputDialog(gameInfo.getPlayer1()+", please put what name you want to have");
            gameInfo.setPlayer1(p1Name);
        }
    }

    private class Player2NameListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String p2Name = JOptionPane.showInputDialog(gameInfo.getPlayer2()+", please put what name you want to have");
            gameInfo.setPlayer2(p2Name);
        }
    }

    private class DefaultThemeListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            die.loadDefault();
            System.out.println("Default loaded");
        }
    }

    private class RedThemeListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            die.loadRed();
            System.out.println("Red loaded");
        }
    }
}
